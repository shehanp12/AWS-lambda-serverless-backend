const express= require("express");
const router = express.Router({
    mergeParams: true
});

router.get('/',getPosts);


module.exports = {
    router,
};

